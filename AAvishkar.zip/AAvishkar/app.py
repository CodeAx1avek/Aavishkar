from flask import Flask, render_template, Response, request, redirect, url_for
import cv2
import face_recognition
import numpy as np
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os
from sqlalchemy import func

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///aavishkar.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
UPLOAD_FOLDER = 'images'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, nullable=False)
    email = db.Column(db.String, nullable=True)
    classroom = db.Column(db.String, nullable=False)
    roll_no = db.Column(db.Integer)
    dob = db.Column(db.DateTime)
    mobile = db.Column(db.Integer)
    Academic_year = db.Column(db.Integer)
    date_time = db.Column(db.DateTime, default=datetime.utcnow, server_default=db.func.now())
    image_filename = db.Column(db.String, nullable=True)

@app.route('/')
def index():
    users = User.query.all()
    return render_template('index.html', users=users)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        if 'image' not in request.files:
            return "No image provided", 400
        
        image = request.files['image']
        
        if image.filename == '':
            return "No selected image", 400
        
        if image:
            dob = datetime.strptime(request.form['dob'], '%Y-%m-%d')

            filename = os.path.join(app.config['UPLOAD_FOLDER'], image.filename)
            image.save(filename)
            new_user = User(username=request.form['username'], email=request.form['email'],
                            classroom=request.form['classroom'], roll_no=request.form['roll_no'],
                            dob=dob,  # Use the parsed datetime object
                            mobile=request.form['mobile'],
                            Academic_year=request.form['Academic_year'], image_filename=image.filename)
            db.session.add(new_user)
            db.session.commit()
            return "Image uploaded and user created successfully"
        
        return "Error uploading image", 500
    
    return render_template('upload.html') 


known_face_encodings = []
known_face_names = []


def load_known_faces():
    users = User.query.all()
    for user in users:
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], user.image_filename)
        user_image = face_recognition.load_image_file(image_path)
        user_face_encoding = face_recognition.face_encodings(user_image)[0]
        known_face_encodings.append(user_face_encoding)
        known_face_names.append(user.username)


camera = cv2.VideoCapture(0)

# Load known faces when the app starts
with app.app_context():
    db.create_all()
    load_known_faces()

def gen_frames():
    while True:
        success, frame = camera.read()
        if not success:
            break
        else:
            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
            
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
            face_names = []

            with app.app_context():
                for face_encoding in face_encodings:
                    matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
                    name = "Unknown"
                    for i, match in enumerate(matches):
                        if match:
                            name = known_face_names[i]
                            break
                    face_names.append(name)

                    for (top, right, bottom, left), name in zip(face_locations, face_names):
                        top *= 4
                        right *= 4
                        bottom *= 4
                        left *= 4

                        user = User.query.filter_by(username=name).first()
                        user_details = f"Name: {user.username}\nClassroom: {user.classroom}\nRoll No: {user.roll_no}"

                        # Define the font style (you can choose other styles as well)
                        font = cv2.FONT_HERSHEY_SIMPLEX

                        cv2.putText(frame, user_details, (left + 6, bottom + 30), font, 0.6, (255, 255, 255), 1)

            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')



@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
